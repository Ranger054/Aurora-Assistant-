Aurora is a virtual assistant created using the C++ programming language.

Changelog:
1. Added .mp3 to .wav file converter.
2. Upgraded ASCII table mode.

How to Use: Download the Aurora.exe file from the repository. Run the .exe file by double-clicking it. Follow the on-screen instructions in the terminal interface. The interface is minimalistic but easy to understand.

Info: Version - Aurora 1.4.0 Date - 17/08/2025